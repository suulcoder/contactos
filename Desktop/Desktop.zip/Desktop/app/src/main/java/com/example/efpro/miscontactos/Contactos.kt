package com.example.efpro.miscontactos

import androidx.lifecycle.Observer
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.ItemTouchHelper
import android.widget.Toast
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.efpro.miscontactos.Adapters.ContactAdapter
import com.example.efpro.miscontactos.viewmodels.ContactViewModel
import com.example.efpro.miscontactos.data.Contact
import kotlinx.android.synthetic.main.activity_contactos.*

@Suppress("PLUGIN_WARNING")
class Contactos : AppCompatActivity() {

    companion object {
        const  val ADD_CONTACT_REQUEST = 1
        const  val EDIT_CONTACT_REQUEST = 2
    }

    private lateinit var ContactViewModel: ContactViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contactos)

        buttonAddContact.setOnClickListener{
            startActivityForResult(
                Intent(this, Crear::class.java),
                ADD_CONTACT_REQUEST
            )
        }

        recycler_view.layoutManager = LinearLayoutManager(this)
        recycler_view.setHasFixedSize(true)

        val adapter = ContactAdapter()

        recycler_view.adapter = adapter
        ContactViewModel = ViewModelProviders.of(this).get(ContactViewModel::class.java)
        ContactViewModel.getAllContacts().observe(this, Observer<List<Contact>>{
            adapter.submitList(it)
        })

        ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.LEFT.or(ItemTouchHelper.RIGHT)){
            override fun onMove(
                recyclerView: androidx.recyclerview.widget.RecyclerView,
                viewHolder: androidx.recyclerview.widget.RecyclerView.ViewHolder,
                target: androidx.recyclerview.widget.RecyclerView.ViewHolder
            ):Boolean{
                return false
            }

            override fun onSwiped(p0: androidx.recyclerview.widget.RecyclerView.ViewHolder, p1: Int) {
                ContactViewModel.delete(adapter.getContactAt(viewHolder.adapterPosition))
                Toast.makeText(baseContext,"Elemento Borrado",Toast.LENGTH_SHORT).show()
            }
        }).attachToRecyclerView(recycler_view)

        adapter.setOnItemClickListener(object: ContactAdapter.OnItemClickListener{
            override  fun onItemClick(contact: Contact){
                val intent = Intent(baseContext, Contacto::class.java)
                intent.putExtra("nombre",contact.nombre)
                intent.putExtra("telefono",contact.tele)
                intent.putExtra("mail",contact.email)
                startActivityForResult(intent, EDIT_CONTACT_REQUEST)
            }

        })
    }
}
