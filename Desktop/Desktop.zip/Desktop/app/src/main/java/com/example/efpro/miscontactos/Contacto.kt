package com.example.efpro.miscontactos

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Contacto : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contacto)
    }
}
